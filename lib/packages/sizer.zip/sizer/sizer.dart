/*
 * Created by Urmish patel on 2018/9/29.
 * email: urmishpatel9@gmail.com
*/
library sizer;

import 'package:flutter/widgets.dart';
import 'package:universal_io/io.dart' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;

part 'extension.dart';

part 'util.dart';

part 'widget.dart';
